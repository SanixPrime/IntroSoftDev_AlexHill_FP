"""
Life Counter
by Alex Hill for SDEV140
Final Project
This is a GUI program that tracks life totals for a game of Magic: The Gathering
Also supported are dice rolls in a pop-up window
"""
import tkinter as tk
from tkinter import ttk
import random as rnd


#Here we subclass the basic window for our main window
class lifeCount(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        self.title('Life Counter')
        self.geometry('650x400+50+50')
        self.resizable(False, False)
        self.columnconfigure(0, weight=10)#3 columns, 4 rows
        self.columnconfigure(1, weight=1)
        self.columnconfigure(2, weight=10)
        self.rowconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        self.rowconfigure(2, weight=1)
        self.rowconfigure(3, weight=1)

        def life1Up():#Left side plus button, increases player 1 life
            lifeNum = int(life1.get())#Variable to hold life total while it gets updated
            lifeNum += 1
            life1.config(state = 'normal')
            life1.delete(0, 5)
            life1.insert(0, str(lifeNum))
            life1.config(state = 'readonly')

        def life1Down():#Left side minus button, decreases player 1 life
            lifeNum = int(life1.get())#Same as above
            lifeNum -= 1
            life1.config(state = 'normal')
            life1.delete(0, 5)
            life1.insert(0, str(lifeNum))
            life1.config(state = 'readonly')

        def life2Up():#Right side plus button, increases player 2 life
            lifeNum = int(life2.get())#Same as above
            lifeNum += 1
            life2.config(state = 'normal')
            life2.delete(0, 5)
            life2.insert(0, str(lifeNum))
            life2.config(state = 'readonly')

        def life2Down():#Right side minus button, decreases player 2 life
            lifeNum = int(life2.get())#Same as above
            lifeNum -= 1
            life2.config(state = 'normal')
            life2.delete(0, 5)
            life2.insert(0, str(lifeNum))
            life2.config(state = 'readonly')

        def resetLife():#Reset button, sets both life totals equal to the value of the entry box
            lifeNum = startLife.get()#Same as above
            if lifeNum.isdigit():
                life1.config(state = 'normal')
                life1.delete(0, 5)
                life1.insert(0, str(lifeNum))
                life1.config(state = 'readonly')
                life2.config(state = 'normal')
                life2.delete(0, 5)
                life2.insert(0, str(lifeNum))
                life2.config(state = 'readonly')

        #Player 1 GUI elements
        plus1 = ttk.Button(master=self, text="+", style='Big.TButton', command = life1Up)
        plus1.grid(column=0, row=0)
        minus1 = ttk.Button(master=self, text="-", style='Big.TButton', command = life1Down)
        minus1.grid(column=0, row=2)
        life1 = ttk.Entry(self,justify = 'center', width = 10, font=('Verdana', 20))
        life1.grid(column=0, row=1)
        life1.insert(0, "20")
        life1.config(state='readonly')
        player1 = ttk.Label(self, text = "Player 1")
        player1.grid(column=0, row=3)

        #Player 2 GUI elements
        plus2 = ttk.Button(master=self, text="+", style='Big.TButton', command = life2Up)
        plus2.grid(column=2, row=0)
        minus2 = ttk.Button(master=self, text="-", style='Big.TButton', command = life2Down)
        minus2.grid(column=2, row=2)
        life2 = ttk.Entry(self,justify = 'center', width = 10, font=('Verdana', 20))
        life2.grid(column=2, row=1)
        life2.insert(0, "20")
        life2.config(state='readonly')
        player2 = ttk.Label(self, text = "Player 2")
        player2.grid(column=2, row=3)

        #GUI elements for resetting life totals
        startLabel = ttk.Label(self, text="Starting Life")
        startLabel.grid(column=1, row=0)
        startLife = ttk.Entry(master=self,justify = 'center', width = 10, font=('Verdana', 20))
        startLife.grid(column=1, row=1)
        startLife.insert(0, "20")
        resetButton = ttk.Button(master=self, text="Reset", command = resetLife)
        resetButton.grid(column=1, row=2)

        #Configure styles
        self.style = ttk.Style(self)
        self.style.configure('TLabel', font=('Verdana', 20))
        self.style.configure('TButton', font=('Verdana', 20))
        self.style.configure('TEntry', font=('Verdana', 44))
        self.style.configure('Big.TButton', font = ('Verdana', 36))

#Instantiate our window class
lifeApp = lifeCount()

#Create images for use by popout window
coin_pic = tk.PhotoImage(file='coin.png')
d6_pic = tk.PhotoImage(file='d6.png')
d20_pic = tk.PhotoImage(file='d20.png')


def diePop():#Create popout window and its functions
    def rolld6():#Roll between 1 and 6
        roll = rnd.randint(1,6)#Container for random number
        dieResult.config(state='normal')
        dieResult.delete(0, 5)
        dieResult.insert(0, str(roll))
        dieResult.config(state='readonly')

    def rolld20():#Roll between 1 and 20
        roll = rnd.randint(1,20)#Same as above
        dieResult.config(state='normal')
        dieResult.delete(0, 5)
        dieResult.insert(0, str(roll))
        dieResult.config(state='readonly')

    def rollcoin():#Simulate a coin flip
        roll = rnd.randint(1,2)#Same as above
        flip = "Heads"#Container for Heads or Tails, depending on random number
        if roll == 2:
            flip = "Tails"
        dieResult.config(state='normal')
        dieResult.delete(0, 5)
        dieResult.insert(0, flip)
        dieResult.config(state='readonly')

    #Create the popout window
    dieRoll = tk.Toplevel(lifeApp)
    dieRoll.title('Roll a die!')
    dieRoll.geometry('500x300+50+50')
    dieRoll.resizable(False, False)
    dieRoll.columnconfigure(0, weight=1)#3 columns, 3 rows
    dieRoll.columnconfigure(1, weight=25)
    dieRoll.columnconfigure(2, weight=1)
    dieRoll.rowconfigure(0, weight=1)
    dieRoll.rowconfigure(1, weight=10)
    dieRoll.rowconfigure(2, weight=1)

    #Labels for the roll buttons
    d6Label = ttk.Label(master = dieRoll, text = "d6")
    d6Label.grid(column = 1, row = 0)
    d20Label = ttk.Label(master = dieRoll, text = "d20")
    d20Label.grid(column = 2, row = 0)
    coinLabel = ttk.Label(master = dieRoll, text = "Coin")
    coinLabel.grid(column = 0, row = 0)

    #Buttons for each roll function
    die6 = ttk.Button(master = dieRoll, image = d6_pic, command = rolld6)
    die6.grid(column = 1, row = 1)
    die20 = ttk.Button(master = dieRoll, image = d20_pic, command = rolld20)
    die20.grid(column = 2, row = 1)
    die2 = ttk.Button(master = dieRoll, image = coin_pic, command = rollcoin)
    die2.grid(column = 0, row = 1)

    #Entry box to hold roll result
    dieResult = ttk.Entry(master = dieRoll, justify='center', width=10, font=('Verdana', 33))
    dieResult.grid(column = 1, row = 2)
    dieResult.insert(0, "?")
    dieResult.config(state='readonly')

#Add button to the main window to access popout window
diceButton = ttk.Button(master=lifeApp, text="Roll a die!", command = diePop)
diceButton.grid(column=1, row=3)


def main():#Main function
    lifeApp.mainloop()#Call mainloop of our main window

if __name__ == "__main__":
  main()